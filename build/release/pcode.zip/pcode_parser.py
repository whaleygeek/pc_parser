start = 'program'
tokens =  ['ASSIGN', 'LPAREN', 'RPAREN', 'LSQUARE', 'WHEN', 'USE', 'RSQUARE', 'COMMA', 'COLON', 'IF', 'THEN', 'ELSE', 'ENDIF', 'WHILE', 'ENDWHILE', 'CASE', 'OF', 'ENDCASE', 'FOR', 'TO', 'ENDFOR', 'REPEAT', 'UNTIL', 'FUNCTION', 'ENDFUNCTION', 'RETURN', 'PROCEDURE', 'ENDPROCEDURE', 'READLINE', 'WRITELINE', 'OUTPUT', 'USERINPUT', 'LEN', 'NOT', 'FALSE', 'TRUE', 'ID', 'NUMBER', 'STRING', 'AS', 'AT', 'OR', 'AND', 'XOR', 'EQUAL', 'NOTEQUAL', 'LESS', 'GREATER', 'LESSEQUAL', 'GREATEREQUAL', 'PLUS', 'MINUS', 'TIMES', 'DIVIDE', 'MOD', 'UNARY']

precedence =  [('left', 'OR'), ('left', 'AND'), ('left', 'XOR'), ('left', 'EQUAL', 'NOTEQUAL'), ('left', 'LESS', 'GREATER', 'LESSEQUAL', 'GREATEREQUAL'), ('left', 'PLUS', 'MINUS'), ('left', 'TIMES', 'DIVIDE', 'MOD'), ('left', 'UNARY')]

# -------------- RULES ----------------

def p_program_1(p):
    '''program : statements'''

def p_statements_1(p):
    '''statements : '''

def p_statements_2(p):
    '''statements : statements statement'''
    backend.statement(p)

def p_statement_1(p):
    '''statement : output_statement'''

def p_statement_2(p):
    '''statement : var_assignment_statement'''

def p_statement_3(p):
    '''statement : array_assignment_statement'''

def p_statement_4(p):
    '''statement : array2d_assignment_statement'''

def p_statement_5(p):
    '''statement : array_initialiser_statement'''

def p_statement_6(p):
    '''statement : if_statement'''

def p_statement_7(p):
    '''statement : while_statement'''

def p_statement_8(p):
    '''statement : repeat_statement'''

def p_statement_9(p):
    '''statement : for_statement'''

def p_statement_10(p):
    '''statement : proc_def_statement'''

def p_statement_11(p):
    '''statement : proc_call_statement'''

def p_statement_12(p):
    '''statement : function_def_statement'''

def p_statement_13(p):
    '''statement : return_statement'''

def p_statement_14(p):
    '''statement : writeline_statement'''

def p_statement_15(p):
    '''statement : case_statement'''

def p_statement_16(p):
    '''statement : use_statement'''

def p_output_statement_1(p):
    '''output_statement : OUTPUT expr'''
    backend.OUTPUT(p, 2)

def p_var_assignment_statement_1(p):
    '''var_assignment_statement : ID ASSIGN expr'''
    backend.assign(p, 1, 3)

def p_array_assignment_statement_1(p):
    '''array_assignment_statement : ID LSQUARE expr RSQUARE ASSIGN expr'''
    backend.array1assign(p, 1, 3, 6)

def p_array2d_assignment_statement_1(p):
    '''array2d_assignment_statement : ID LSQUARE expr RSQUARE LSQUARE expr RSQUARE ASSIGN expr'''
    backend.array2assign(p, 1, 3, 6, 9)

def p_initialiser_expr_1(p):
    '''initialiser_expr : '''
    backend.lempty(p)

def p_initialiser_expr_2(p):
    '''initialiser_expr : expr'''
    backend.litem(p, 1)

def p_initialiser_expr_3(p):
    '''initialiser_expr : initialiser_expr COMMA expr'''
    backend.lappend(p, 1, 3)

def p_array_initialiser_statement_1(p):
    '''array_initialiser_statement : ID ASSIGN LSQUARE initialiser_expr RSQUARE'''
    backend.arrayinit(p, 1, 4)

def p_file_1(p):
    '''file : expr'''
    backend.copy(p, 1)

def p_readline_expr_1(p):
    '''readline_expr : READLINE LPAREN file COMMA expr RPAREN'''
    backend.READLINE(p, 3, 5)

def p_writeline_statement_1(p):
    '''writeline_statement : WRITELINE LPAREN file COMMA expr COMMA expr RPAREN'''
    backend.WRITELINE(p, 3, 5, 7)

def p_if_statement_1(p):
    '''if_statement : IF expr THEN _embed0_if_statement statements else_clause ENDIF'''
    backend.ENDIF(p)

def p__embed0_if_statement(p):
    '''_embed0_if_statement : '''
    backend.IF(p, -2)

def p_else_clause_1(p):
    '''else_clause : '''

def p_else_clause_2(p):
    '''else_clause : ELSE _embed0_else_clause statements'''

def p__embed0_else_clause(p):
    '''_embed0_else_clause : '''
    backend.ELSE(p)

def p_while_statement_1(p):
    '''while_statement : WHILE expr _embed0_while_statement statements ENDWHILE'''
    backend.ENDWHILE(p)

def p__embed0_while_statement(p):
    '''_embed0_while_statement : '''
    backend.WHILE(p, -1)

def p_repeat_statement_1(p):
    '''repeat_statement : REPEAT _embed0_repeat_statement statements UNTIL expr'''
    backend.UNTIL(p, 5)

def p__embed0_repeat_statement(p):
    '''_embed0_repeat_statement : '''
    backend.REPEAT(p)

def p_for_statement_1(p):
    '''for_statement : FOR ID ASSIGN expr TO expr _embed0_for_statement statements ENDFOR'''
    backend.ENDFOR(p)

def p__embed0_for_statement(p):
    '''_embed0_for_statement : '''
    backend.FOR(p, -5, -3, -1)

def p_case_option_1(p):
    '''case_option : WHEN expr COLON _embed0_case_option statements'''
    backend.ENDWHEN(p)

def p__embed0_case_option(p):
    '''_embed0_case_option : '''
    backend.WHEN(p, -2)

def p_case_options_1(p):
    '''case_options : '''

def p_case_options_2(p):
    '''case_options : case_options case_option'''

def p_case_statement_1(p):
    '''case_statement : CASE expr OF _embed0_case_statement case_options ELSE _embed1_case_statement statements _embed2_case_statement ENDCASE'''
    backend.ENDCASE(p)

def p__embed0_case_statement(p):
    '''_embed0_case_statement : '''
    backend.CASE(p, -2)

def p__embed1_case_statement(p):
    '''_embed1_case_statement : '''
    backend.CASEELSE(p)

def p__embed2_case_statement(p):
    '''_embed2_case_statement : '''
    backend.ENDCASEELSE(p)

def p_use_statement_1(p):
    '''use_statement : USE STRING'''
    backend.USE(p, 2)

def p_use_statement_2(p):
    '''use_statement : USE STRING AS STRING'''
    backend.USE(p, 2, 4)

def p_fnproc_def_params_1(p):
    '''fnproc_def_params : '''
    backend.lempty(p)

def p_fnproc_def_params_2(p):
    '''fnproc_def_params : ID'''
    backend.litem(p, 1)

def p_fnproc_def_params_3(p):
    '''fnproc_def_params : fnproc_def_params COMMA ID'''
    backend.lappend(p, 1, 3)

def p_function_def_statement_1(p):
    '''function_def_statement : FUNCTION ID LPAREN fnproc_def_params RPAREN _embed0_function_def_statement statements ENDFUNCTION'''
    backend.ENDFUNCTION(p)

def p__embed0_function_def_statement(p):
    '''_embed0_function_def_statement : '''
    backend.FUNCTION(p, -4, -2)

def p_return_statement_1(p):
    '''return_statement : RETURN expr'''
    backend.RETURN(p, 2)

def p_proc_def_statement_1(p):
    '''proc_def_statement : PROCEDURE ID LPAREN fnproc_def_params RPAREN _embed0_proc_def_statement statements ENDPROCEDURE'''
    backend.ENDPROCEDURE(p)

def p__embed0_proc_def_statement(p):
    '''_embed0_proc_def_statement : '''
    backend.PROCEDURE(p, -4, -2)

def p_fnproc_call_params_1(p):
    '''fnproc_call_params : '''
    backend.lempty(p)

def p_fnproc_call_params_2(p):
    '''fnproc_call_params : expr'''
    backend.litem(p, 1)

def p_fnproc_call_params_3(p):
    '''fnproc_call_params : fnproc_call_params COMMA expr'''
    backend.lappend(p, 1, 3)

def p_proc_call_statement_1(p):
    '''proc_call_statement : ID LPAREN fnproc_call_params RPAREN'''
    backend.proccall(p, 1, 3)

def p_proc_call_statement_2(p):
    '''proc_call_statement : ID AT ID LPAREN fnproc_call_params RPAREN'''
    backend.libproccall(p, 1, 3, 5)

def p_fn_call_expr_1(p):
    '''fn_call_expr : ID LPAREN fnproc_call_params RPAREN'''
    backend.fncall(p, 1, 3)

def p_fn_call_expr_2(p):
    '''fn_call_expr : ID AT ID LPAREN fnproc_call_params RPAREN'''
    backend.libfncall(p, 1, 3, 5)

def p_expr_1(p):
    '''expr : TRUE'''
    backend.boolean(p, "True")

def p_expr_2(p):
    '''expr : FALSE'''
    backend.boolean(p, "False")

def p_expr_3(p):
    '''expr : NUMBER'''
    backend.number(p, 1)

def p_expr_4(p):
    '''expr : ID'''
    backend.id(p, 1)

def p_expr_5(p):
    '''expr : STRING'''
    backend.string(p, 1)

def p_expr_6(p):
    '''expr : LPAREN expr RPAREN'''
    backend.bracket(p, 2)

def p_expr_7(p):
    '''expr : USERINPUT'''
    backend.USERINPUT(p)

def p_expr_8(p):
    '''expr : LEN LPAREN ID RPAREN'''
    backend.LEN(p, 3)

def p_expr_9(p):
    '''expr : expr PLUS expr'''
    backend.plus(p, 1, 3)

def p_expr_10(p):
    '''expr : expr MINUS expr'''
    backend.minus(p, 1, 3)

def p_expr_11(p):
    '''expr : expr TIMES expr'''
    backend.times(p, 1, 3)

def p_expr_12(p):
    '''expr : expr DIVIDE expr'''
    backend.divide(p, 1, 3)

def p_expr_13(p):
    '''expr : expr MOD expr'''
    backend.MOD(p, 1, 3)

def p_expr_14(p):
    '''expr : MINUS expr %prec UNARY'''
    backend.uminus(p,2)

def p_expr_15(p):
    '''expr : PLUS expr'''
    backend.uplus(p, 2)

def p_expr_16(p):
    '''expr : NOT expr %prec UNARY'''
    backend.NOT(p, 2)

def p_expr_17(p):
    '''expr : expr EQUAL expr'''
    backend.equal(p, 1, 3)

def p_expr_18(p):
    '''expr : expr NOTEQUAL expr'''
    backend.notequal(p, 1, 3)

def p_expr_19(p):
    '''expr : expr LESSEQUAL expr'''
    backend.lessequal(p, 1, 3)

def p_expr_20(p):
    '''expr : expr GREATEREQUAL expr'''
    backend.greaterequal(p, 1, 3)

def p_expr_21(p):
    '''expr : expr GREATER expr'''
    backend.greater(p, 1, 3)

def p_expr_22(p):
    '''expr : expr LESS expr'''
    backend.less(p, 1, 3)

def p_expr_23(p):
    '''expr : expr AND expr'''
    backend.AND(p, 1, 3)

def p_expr_24(p):
    '''expr : expr OR expr'''
    backend.OR(p, 1, 3)

def p_expr_25(p):
    '''expr : expr XOR expr'''
    backend.XOR(p, 1, 3)

def p_expr_26(p):
    '''expr : readline_expr'''
    backend.copy(p, 1)

def p_expr_27(p):
    '''expr : fn_call_expr'''
    backend.copy(p, 1)

def p_expr_28(p):
    '''expr : ID LSQUARE expr RSQUARE'''
    backend.array1dexpr(p, 1, 3)

def p_expr_29(p):
    '''expr : ID LSQUARE expr RSQUARE LSQUARE expr RSQUARE'''
    backend.array2dexpr(p, 1, 3, 6)

# -------------- RULES END ----------------


backend = None
def set_backend(b):
    global backend
    backend = b

if __name__ == '__main__':
    from ply import *
    yacc.yacc()

